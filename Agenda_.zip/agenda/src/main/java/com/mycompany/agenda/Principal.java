/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bruno.v.oliveira
 */
public class Principal {
    
    public static void main(String[] args){
        Agenda a = new Agenda();
        ControladorCadastro controlador = new ControladorCadastro(a);
    }
}
